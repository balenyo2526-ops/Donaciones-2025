# Donaciones - Sitio estático (Moderno y elegante)

Sitio estático listo para subir a cualquier hosting (Netlify, Vercel, GitHub Pages) o servir con un servidor estático simple.

### ¿Qué incluye?
- index.html (landing + datos bancarios)
- donar.html (PayPal button + copia de cuenta)
- styles.css (paleta moderna: navy + oro)

### Instrucciones rápidas
1. Reemplaza `YOUR_PAYPAL_CLIENT_ID` en `donar.html` por tu PayPal Client-ID (sandbox o live).
2. Si deseas otra moneda, cambia `currency=USD` en la carga del SDK.
3. Sube los archivos a tu hosting o prueba localmente con `npx serve` o `python -m http.server 8000`.
4. Verifica que la transferencia bancaria muestra la cuenta correcta: `4236535551`.

### Personalización
- Nombre del sitio, logo y correo en `index.html`.
- Si quieres, puedo generar una versión con HTTPS-ready config o añadir formulario de recibos y webhooks.
